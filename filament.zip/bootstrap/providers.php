<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\Filament\AdminPanelProvider::class,
    Bepsvpt\SecureHeaders\SecureHeadersServiceProvider::class,
];
